package com.example.homework4

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
